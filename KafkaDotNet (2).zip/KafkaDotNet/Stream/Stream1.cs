using System;
using System.Threading.Tasks;
using Streamiz.Kafka.Net;
using Streamiz.Kafka.Net.SerDes;
using Streamiz.Kafka.Net.Stream;
using Confluent.Kafka;
using Streamiz.Kafka.Net.Table;

class Stream1 {
    static async Task Main(string[] args)
    {
        var config = new StreamConfig<StringSerDes, StringSerDes>();
        config.ApplicationId = "Stream1";
        config.BootstrapServers = "216.48.191.14:3400,216.48.191.18:3400,216.48.191.74:3400,216.48.191.109:3400";
        config.AutoOffsetReset = AutoOffsetReset.Earliest;

        StreamBuilder builder = new StreamBuilder();

        IKStream<string, string> KS1 = builder.Stream<string, string>("TopicX");
        IKStream<string, string> KS2 = KS1.MapValues((k, v) => v.ToLower());
        IKStream<string, string> KS3 = KS2.FlatMapValues((k, v) => v.Split(" "));
        IKGroupedStream<string, string> KS4 = KS3.GroupBy((k, v) => v);
        IKTable<string, string> KT1 = KS4.Count().MapValues((k, v) => ((int)v).ToString());

        KT1.ToStream().To("TopicY",new StringSerDes(),new StringSerDes());

        Topology t = builder.Build();

        KafkaStream stream = new KafkaStream(t, config);

        Console.CancelKeyPress += (o, e) => {stream.Dispose();};

        await stream.StartAsync();
    }
}
