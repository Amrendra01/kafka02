using System;
using System.Threading.Tasks;
using Streamiz.Kafka.Net;
using Streamiz.Kafka.Net.SerDes;
using Streamiz.Kafka.Net.Stream;
using System.Globalization;
using Confluent.Kafka;

class Stream0 {
    static async Task Main(string[] args)
    {
        var config = new StreamConfig<StringSerDes, StringSerDes>();
        config.ApplicationId = "Stream0";
        config.BootstrapServers = "216.48.191.14:3400,216.48.191.18:3400,216.48.191.74:3400,216.48.191.109:3400";
        config.AutoOffsetReset = AutoOffsetReset.Earliest;

        StreamBuilder builder = new StreamBuilder();

        IKStream<string, string> KS1 = builder.Stream<string, string>("Payment");
        IKStream<string, string> KS2 = KS1.MapValues((k, v) => ConversionRate(v));
        KS2.To("RealPayment");

        Topology t = builder.Build();

        KafkaStream stream = new KafkaStream(t, config);

        Console.CancelKeyPress += (o, e) => {stream.Dispose();};

        await stream.StartAsync();
    }

    private static string ConversionRate(string v)
    {
        string[] splits = v.Split(",");
        
        return "訂單號 : " + splits[0] + " 產品編號 : " + splits[1] + " 數量 : " + 
        Math.Round(float.Parse(splits[2], 
        CultureInfo.InvariantCulture.NumberFormat)*new Random().NextInt64(10,25)*new Random().NextDouble(), 2, MidpointRounding.AwayFromZero) + " 人民幣";
    }
}
