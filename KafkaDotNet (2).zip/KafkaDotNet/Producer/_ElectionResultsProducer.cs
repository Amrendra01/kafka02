using Confluent.Kafka;
using System;
using Microsoft.Extensions.Configuration;
using System.Threading.Tasks;
using System.Threading;

class _ElectionResultsProducer {
	async Task SyncSendAsync(string Topic, IConfiguration Config)
    {
         using (var producer = new ProducerBuilder<string, string>(Config.AsEnumerable()).Build())
        {
            String[] Parties = {"AAP", "BSP", "BJP", "INC", "JDS","CPM", "AIMIM"};
            String[] Districts = {"Bagalkot", "Belagavi", "Dharwad", "Gadag", "Haveri", "Uttara Kannada", 
        		"Vijayapura", "Ballary", "Bidar", "Kalaburagi", "Koppal", "Raichur", "Vijayanagara","Yadigr", "Bangalore Urban", 
        		"Bangalore Rural", "Chikkaballapura", "Chitradurga", "Davanagere", "Kolar", "Ramanagara", "Shimoga", "Tumakuru", 
        		"Chamarajanagar", "Chikmagalur", "Dakshina Kannada", "Hassan", "Kodagu", "Mandya", "Mysore", "Udupi"};

            for (int i=0; i<=10000; i++ ) {
                Thread.Sleep(TimeSpan.FromMilliseconds(500));
                String Lead = new Random().Next(1, 5).ToString();
                String District = Districts[new Random().Next(Districts.Length)];
                String Party = Parties[new Random().Next(Parties.Length)];        

                var report = await producer.ProduceAsync(Topic,new Message<string, string>{Key = District, Value = Party+"-"+Lead});
                Console.WriteLine("Data : " + District + "=>" + Party+"-"+Lead + " [Partition : " + 
                report.Partition.Value +"] [Offset : "+report.Offset.Value + "]");
            }            
        }       
    }

    static async Task Main(string[] args)
    {
        if (args.Length != 1) {Console.WriteLine("Missing Config !!");}
        IConfiguration KafkaConfig = new ConfigurationBuilder().AddIniFile(args[0]).Build();

        const string Topic = "Elections";

        await new _ElectionResultsProducer().SyncSendAsync(Topic, KafkaConfig);
    }
}
