using Confluent.Kafka;
using System;
using System.Threading.Tasks;
using System.Text;

class Producer2 {
    static async Task Main(string[] args)
    {
        const string Topic = "tweetdata";
        var config = new ProducerConfig{BootstrapServers = "216.48.191.14:3400,216.48.191.18:3400,216.48.191.74:3400,216.48.191.109:3400"};

        using var TweetPartitioner = new ProducerBuilder<string, string>(config)
            .SetPartitioner(Topic,
            (string topicName, int partitionCount, ReadOnlySpan<byte> keyData, bool keyIsNull) =>
            {
                var keyString = Encoding.UTF8.GetString(keyData.ToArray());

                /*var intPrefix= int.Parse(keyString.Split("-").FirstOrDefault());
                var hash = Crc32.Hash(BitConverter.GetBytes(intPrefix));                
                return (Partition)(Math.Abs(BinaryPrimitives.ReadUInt32BigEndian(hash)) % partitionCount);*/

                int p = 0;

                if (keyString.Equals("IN") || keyString.Equals("SL") || keyString.Equals("BT"))
                    p = 1;
                else if (keyString.Equals("US") || keyString.Equals("UK"))
                    p = 2;        
                else
                    p = 0;                

                return p;
            }).Build();

        var report1 = await TweetPartitioner.ProduceAsync(Topic,new Message<string, string>{Key = "US",Value = "message1"});
        Console.WriteLine("report1.Partition.Value : "+report1.Partition.Value);
        var report2 = await TweetPartitioner.ProduceAsync(Topic,new Message<string, string>{Key = "UK",Value = "message2"});
        Console.WriteLine("report2.Partition.Value : "+report2.Partition.Value);
        var report3 = await TweetPartitioner.ProduceAsync(Topic,new Message<string, string>{Key = "IN",Value = "message3"}); 
        Console.WriteLine("report3.Partition.Value : "+report3.Partition.Value);
        var report4 = await TweetPartitioner.ProduceAsync(Topic,new Message<string, string>{Key = "SL",Value = "message4"});
        Console.WriteLine("report4.Partition.Value : "+report4.Partition.Value);
        var report5 = await TweetPartitioner.ProduceAsync(Topic,new Message<string, string>{Key = "BT",Value = "message5"});
        Console.WriteLine("report5.Partition.Value : "+report5.Partition.Value);
        var report6 = await TweetPartitioner.ProduceAsync(Topic,new Message<string, string>{Key = "JP",Value = "message6"}); 
        Console.WriteLine("report6.Partition.Value : "+report6.Partition.Value);       
        var report7 = await TweetPartitioner.ProduceAsync(Topic,new Message<string, string>{Key = "RU",Value = "message7"});
        Console.WriteLine("report7.Partition.Value : "+report7.Partition.Value); 

        using var NormalProducer = new ProducerBuilder<int, string>(config).Build();
        var report8 = await NormalProducer.ProduceAsync(Topic,new Message<int, string>{Key = 66,Value = "Execute Order 66"});
        Console.WriteLine("report8.Partition.Value : "+report8.Partition.Value);        
    }
}
