using Confluent.Kafka;
using System;
using Microsoft.Extensions.Configuration;
using System.Threading.Tasks;
using System.Threading;

class _GlobalOrdersProducer {
    async Task SyncSendAsync(string Topic, IConfiguration Config)
    {
         using (var producer = new ProducerBuilder<string, string>(Config.AsEnumerable()).Build())
        {
            foreach (string line in System.IO.File.ReadLines(@"/media/prathamos/Work/Work/Training/Kafka/GlobalOrders.csv"))
            {  
            var report = await producer.ProduceAsync(Topic,new Message<string, string>{Value = line});
            Console.WriteLine("Data : " + line + " [Partition : " + report.Partition.Value +"] [Offset : "+report.Offset.Value + "]");
            Thread.Sleep(TimeSpan.FromMilliseconds(500));  
            }            
        }       
    }

    static async Task Main(string[] args)
    {
        if (args.Length != 1) {Console.WriteLine("Missing Config !!");}
        IConfiguration KafkaConfig = new ConfigurationBuilder().AddIniFile(args[0]).Build();

        const string Topic = "Payment";

        await new _GlobalOrdersProducer().SyncSendAsync(Topic, KafkaConfig);
    }
}
