using Confluent.Kafka;
using System;
using Microsoft.Extensions.Configuration;
using System.Threading.Tasks.Dataflow;
using System.Threading.Tasks;
using System.Threading;

class Producer0 {
    void SyncSend(string Topic, IConfiguration Config)
    {
         using (var producer = new ProducerBuilder<string, string>(Config.AsEnumerable()).Build())
        {
            string[] users = { "rakesh", "jsmith", "sgarcia", "jbernard", "htanaka", "awalther" };
            string[] items = { "bat", "alarm clock", "t-shirts", "gift card", "batteries" };            
            var numProduced = 0;
            Random rnd = new Random();
            const int numMessages = 1000;

            for (int i = 0; i < numMessages; ++i)
            {
                var user = users[rnd.Next(users.Length)];
                var item = items[rnd.Next(items.Length)];

                producer.Produce(Topic, new Message<string, string> { Value = item },
                //producer.Produce(Topic, new Message<string, string> { Key = user, Value = item },
                    (deliveryReport) =>
                    {
                        if (deliveryReport.Error.Code != ErrorCode.NoError) {
                            Console.WriteLine($"Failed to deliver message: {deliveryReport.Error.Reason}");
                        }
                        else {
                            Console.WriteLine($"Produced event to topic {Topic}: key = {user,-10} value = {item}");
                            numProduced += 1;
                        }
                    });
            }

            producer.Flush(TimeSpan.FromSeconds(10));
            Console.WriteLine($"{numProduced} messages were produced to topic {Topic}");
        }       
    }

    static void Main(string[] args)
    {
        if (args.Length != 1) {Console.WriteLine("Missing Config !!");}
        IConfiguration KafkaConfig = new ConfigurationBuilder().AddIniFile(args[0]).Build();
        //KafkaConfig["linger.ms"] = "50";
        //KafkaConfig["batch.size"] = "50000";
        /*KafkaConfig["acks"] = "leader";
        KafkaConfig["acks"] = "none";
        KafkaConfig["acks"] = "all";*/

        const string Topic = "topic1";

        new Producer0().SyncSend(Topic, KafkaConfig);
    }
}
