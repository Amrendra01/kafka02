using Confluent.Kafka;
using System;
using Confluent.SchemaRegistry;
using Confluent.SchemaRegistry.Serdes;
using Training.Kafka;
using System.Threading.Tasks;

class Producer5 {
        static async Task Main(string[] args)
        {
            string bootstrapServers = "216.48.191.14:3400,216.48.191.18:3400,216.48.191.74:3400,216.48.191.109:3400";
            string schemaRegistryUrl = "http://216.48.191.250:3500";
            string topicName = "Customer";

            var producerConfig = new ProducerConfig{BootstrapServers = bootstrapServers};
            var schemaRegistryConfig = new SchemaRegistryConfig{Url = schemaRegistryUrl};

            using (var schemaRegistry = new CachedSchemaRegistryClient(schemaRegistryConfig))
            using (var producer =
                new ProducerBuilder<string, Customer>(producerConfig)
                    .SetValueSerializer(new AvroSerializer<Customer>(schemaRegistry))
                    .Build())
            {
                Customer customer = new Customer {
                    age = 35,
                    first_name = "Bruce",
                    last_name = "Wayne",
                    mobile = 1234,
                    customer_address = new CustomerAddress{address = "Wayne Manor", city = "Gotham"} 
                    };


                await producer
                .ProduceAsync(topicName, new Message<string, Customer> { Key = "AwesomeLegend", Value = customer })
                .ContinueWith(task =>
                    {
                        if (!task.IsFaulted)
                        {
                            Console.WriteLine($"produced to: {task.Result.TopicPartitionOffset}");
                            return;
                        }

                        Console.WriteLine($"error producing message: {task.Exception.InnerException}");
                    });                
            }

            using var NormalProducer = new ProducerBuilder<int, string>(producerConfig).Build();
            var report = await NormalProducer.ProduceAsync(topicName,new Message<int, string>{Key = 999,Value = "Install Virus in Company"});
            Console.WriteLine("report : "+report.Message);             
        }
}
