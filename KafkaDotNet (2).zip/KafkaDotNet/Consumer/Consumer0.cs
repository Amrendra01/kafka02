using Confluent.Kafka;
using System;
using System.Threading;
using Microsoft.Extensions.Configuration;

class Consumer0 {

    static void Main(string[] args)
    {
        if (args.Length != 1) {Console.WriteLine("Missing Config !!");}
        IConfiguration KafkaConfig = new ConfigurationBuilder().AddIniFile(args[0]).Build();

        KafkaConfig["group.id"] = "firsttry";
        KafkaConfig["auto.offset.reset"] = "earliest";

        const string topic = "topic1";

        CancellationTokenSource cts = new CancellationTokenSource();
        Console.CancelKeyPress += (_, e) => {
            e.Cancel = true; // prevent the process from terminating.
            cts.Cancel();
        };

        using (var consumer = new ConsumerBuilder<string, string>(KafkaConfig.AsEnumerable()).Build())
        {
            consumer.Subscribe(topic);

            try {
                while (true) {
                    var cr = consumer.Consume(cts.Token);
                    Console.WriteLine($"Consumed event from topic {topic} with key {cr.Message.Key,-10} and value {cr.Message.Value} and partition {cr.Partition.Value} and offset {cr.Offset.Value}");
                }
            }
            catch (OperationCanceledException) {
                // Ctrl-C was pressed.
            }
            finally{
                consumer.Close();
            }
        }
    }
}
