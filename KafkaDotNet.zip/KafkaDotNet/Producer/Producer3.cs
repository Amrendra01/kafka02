using Confluent.Kafka;
using System;
using System.Text;
using System.Text.Json;

class Producer3 {
    static void Main(string[] args)
    {
        var config = new ProducerConfig{BootstrapServers = "216.48.191.14:3400,216.48.191.18:3400,216.48.191.74:3400,216.48.191.109:3400"};
        const string Topic = "Orders";

        var producerBuilder = new ProducerBuilder<string, Order>(config);
        producerBuilder.SetValueSerializer(new OrderSerializer());
        var producer = producerBuilder.Build();

        Order o = new Order();
        o.OrderId_ = 4545;
        o.ItemName_ = "Fridge";
        o.ItemDesc_ = "Samsung";
        o.AmountTotal_ = 70000;  

        producer.Produce(Topic, new Message<string, Order> { Key = "ORD-1234", Value = o },
            (deliveryReport) =>
            {
                if (deliveryReport.Error.Code != ErrorCode.NoError) {
                    Console.WriteLine($"Failed to deliver message: {deliveryReport.Error.Reason}");
                }
                else {
                    Console.WriteLine($"Produced event to topic {Topic}: partition = {deliveryReport.Partition.Value.ToString()}");
                }
            }); 

        producer.Flush(TimeSpan.FromSeconds(10));
        Console.WriteLine("Done");                   
    }
}

public class OrderSerializer : Confluent.Kafka.ISerializer<Order>
{
    public byte[] Serialize(Order data, SerializationContext context)
    {
        return Encoding.ASCII.GetBytes(JsonSerializer.Serialize<Order>(data));
    }
}

public class Order
{
    private int OrderId;
    private String ItemName;	
    private String ItemDesc;	
    private int AmountTotal;
    public int OrderId_{get { return OrderId; }set { OrderId = value; }}
    public String ItemName_{get { return ItemName; }set { ItemName = value; }}
    public String ItemDesc_{get { return ItemDesc; }set { ItemDesc = value; }}
    public int AmountTotal_{get { return AmountTotal; }set { AmountTotal = value; }}            
}
